#this is the pacman class.

#import packages
import pygame, math, random, sys
from pygame.locals import *
from resources import *

#Pacman class for our pacman game
class Pacman (pygame.sprite.Sprite):
  def __init__(self):
    super().__init__()
    self.direction = "down"
    self.image = pacman_directions[self.direction][0]
    self.x = 50
    self.y = 70
    self.speed = 5
    self.num = 0
    self.chomp_delay = 5
  def update(self):
    return
    
  def get_rect(self):
    return pygame.Rect(self.x, self.y, 32, 32)
    
  def chomp(self):
    if self.chomp_delay > 0:
      self.chomp_delay -= 1
    else:
    
      if self.num == 0:
        self.num = 1
      else:
        self.num = 0
      self.image = pacman_directions[self.direction][self.num]
      self.chomp_delay = 5

  def move(self):
    if self.direction == "down":
      self.y += self.speed
    elif self.direction == "up":
      self.y -= self.speed
    elif self.direction == "left":
      self.x -= self.speed
    elif self.direction == "right":
      self.x += self.speed
    if 200<self.y<240 and 400 < self.x < 440:
      self.x = 40
    if 200<self.y<240 and 0 < self.x < 40:
      self.x = 400 
      
  def get_pix_ahead(self):
    box = self.get_rect()
    if self.direction == "down":
      return (box.midbottom[0], box.midbottom[1] + 1)
    elif self.direction == "up":
      return (box.midtop[0], box.midtop[1] -1)
    elif self.direction == "left":
      return (box.midleft[0] - 1, box.midleft[1])
    elif self.direction == "right":
      return (box.midright[0] + 1, box.midright[1])
      
  def clamp(self):
      #bound x
      if self.x < 10:
          self.x = 10
      elif self.x > SCREEN_WIDTH - 42:
          self.x = SCREEN_WIDTH - 42
      #bound y
      if self.y < 10:
          self.y = 10
      elif self.y > SCREEN_HEIGHT - 42:
          self.y = SCREEN_HEIGHT - 42      
