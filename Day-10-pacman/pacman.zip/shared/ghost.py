#This is our ghost class

#import modules
import pygame, math, random, sys
from pygame.locals import *
from resources import *

#make ghost behave similar to pacman
from pacman import *
class Ghost (Pacman):
  def __init__(self, name, x, y):
    super().__init__()
    self.name = name
    self.direction = random.choice(['left', 'right', 'up', 'down'])
    self.image = ghost_pics[self.direction][self.name][0]
    self.rect = self.image.get_rect()
    self.x = x
    self.y = y
    self.timer = 20
    
  def chomp(self):
    if self.num == 0:
      self.num = 1
    else:
      self.num = 0
    self.image = ghost_pics[self.direction][self.name][self.num]

  def move(self, surface):
    self.timer -= 1
    loc = self.get_pix_ahead()
    color = surface.get_at(loc)
    if dist(color, wall_color) > 5 and self.timer > 0:
      if self.direction == 'left':
        self.x -= self.speed
      elif self.direction == 'right':
        self.x += self.speed
      elif self.direction == 'up':
        self.y -= self.speed
      elif self.direction == 'down':
        self.y += self.speed
      self.clamp()
    else:
      self.direction = random.choice(['left', 'right', 'up', 'down'])
      self.timer = 20
    