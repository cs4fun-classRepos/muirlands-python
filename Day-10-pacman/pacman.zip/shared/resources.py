import pygame, sys, random, math
from pygame.locals import *
from pygame.transform import *

#screen dimensions
SCREEN_WIDTH = 228 * 2
SCREEN_HEIGHT = 247 * 2

#load up all the sprite sheet
sheet = pygame.image.load('pacSprites.png')

#load the empty arena
arena = pygame.image.load('arena.png')
arena = scale2x(arena)

#load pacman images
pacman_r1 = scale2x(sheet.subsurface(455, 0, 16, 16))
pacman_r2 = scale2x(sheet.subsurface(471, 0, 16, 16))
pacman_l1 = scale2x(sheet.subsurface(455, 16, 16, 16))
pacman_l2 = scale2x(sheet.subsurface(471, 16, 16, 16))
pacman_u1 = scale2x(sheet.subsurface(455, 32, 16, 16))
pacman_u2 = scale2x(sheet.subsurface(471, 32, 16, 16))
pacman_d1 = scale2x(sheet.subsurface(455, 48, 16, 16))
pacman_d2 = scale2x(sheet.subsurface(471, 48, 16, 16))

#add wall color
wall_color = (100, 186, 172, 255)

#this dictionary stores the two pictures used for
#animation for each direction for the pacman
pacman_directions = {
    "right": (pacman_r1, pacman_r2),
    "left": (pacman_l1, pacman_l2),
    "up": (pacman_u1, pacman_u2),
    "down": (pacman_d1, pacman_d2)
}
# power ups
coke = scale2x(sheet.subsurface(487, 48, 16, 16))
wine = scale2x(sheet.subsurface(503, 48, 16, 16))
cucumber = scale2x(sheet.subsurface(519, 48, 16, 16))
apple = scale2x(sheet.subsurface(535, 48, 16, 16))
grapes = scale2x(sheet.subsurface(551, 48, 16, 16))
torch = scale2x(sheet.subsurface(567, 48, 16, 16))
bread = scale2x(sheet.subsurface(583, 48, 16, 16))
pancake = scale2x(sheet.subsurface(599, 48, 16, 16))

powerups = [(coke, 90, 70), (wine, 355, 70), (cucumber, 335, 320),
            (apple, 90, 305), (grapes, 10, 455), (torch, 410, 455),
            (bread, 410, 5), (pancake, 10, 5)]


def dist(c1, c2):
    return abs(c1[0] - c2[0]) + abs(c1[1] - c2[1]) + abs(c1[2] - c2[2])


#pellet image
pellet_image = scale2x(sheet.subsurface(10, 10, 5, 5))

#ghost images
#cut blinky
blinky_r1 = scale2x(sheet.subsurface(457, 64, 14, 14))
blinky_r2 = scale2x(sheet.subsurface(473, 64, 14, 14))
blinky_l1 = scale2x(sheet.subsurface(489, 64, 14, 14))
blinky_l2 = scale2x(sheet.subsurface(505, 64, 14, 14))
blinky_u1 = scale2x(sheet.subsurface(521, 64, 14, 14))
blinky_u2 = scale2x(sheet.subsurface(537, 64, 14, 14))
blinky_d1 = scale2x(sheet.subsurface(553, 64, 14, 14))
blinky_d2 = scale2x(sheet.subsurface(569, 64, 14, 14))

#cut pinky
pinky_r1 = scale2x(sheet.subsurface(457, 81, 14, 14))
pinky_r2 = scale2x(sheet.subsurface(473, 81, 14, 14))
pinky_l1 = scale2x(sheet.subsurface(489, 81, 14, 14))
pinky_l2 = scale2x(sheet.subsurface(505, 81, 14, 14))
pinky_u1 = scale2x(sheet.subsurface(521, 81, 14, 14))
pinky_u2 = scale2x(sheet.subsurface(537, 81, 14, 14))
pinky_d1 = scale2x(sheet.subsurface(553, 81, 14, 14))
pinky_d2 = scale2x(sheet.subsurface(569, 81, 14, 14))

#cut inky
inky_r1 = scale2x(sheet.subsurface(457, 97, 14, 14))
inky_r2 = scale2x(sheet.subsurface(473, 97, 14, 14))
inky_l1 = scale2x(sheet.subsurface(489, 97, 14, 14))
inky_l2 = scale2x(sheet.subsurface(505, 97, 14, 14))
inky_u1 = scale2x(sheet.subsurface(521, 97, 14, 14))
inky_u2 = scale2x(sheet.subsurface(537, 97, 14, 14))
inky_d1 = scale2x(sheet.subsurface(553, 97, 14, 14))
inky_d2 = scale2x(sheet.subsurface(569, 97, 14, 14))

#cut clyde
clyde_r1 = scale2x(sheet.subsurface(457, 113, 14, 14))
clyde_r2 = scale2x(sheet.subsurface(473, 113, 14, 14))
clyde_l1 = scale2x(sheet.subsurface(489, 113, 14, 14))
clyde_l2 = scale2x(sheet.subsurface(505, 113, 14, 14))
clyde_u1 = scale2x(sheet.subsurface(521, 113, 14, 14))
clyde_u2 = scale2x(sheet.subsurface(537, 113, 14, 14))
clyde_d1 = scale2x(sheet.subsurface(553, 113, 14, 14))
clyde_d2 = scale2x(sheet.subsurface(569, 113, 14, 14))

#define the images of ghosts
ghost_pics = {
    'right': {
        'blinky': (blinky_r1, blinky_r2),
        'pinky': (pinky_r1, pinky_r2),
        'inky': (inky_r1, inky_r2),
        'clyde': (clyde_r1, clyde_r2)
    },
    'left': {
        'blinky': (blinky_l1, blinky_l2),
        'pinky': (pinky_l1, pinky_l2),
        'inky': (inky_l1, inky_l2),
        'clyde': (clyde_l1, clyde_l2)
    },
    'up': {
        'blinky': (blinky_u1, blinky_u2),
        'pinky': (pinky_u1, pinky_u2),
        'inky': (inky_u1, inky_u2),
        'clyde': (clyde_u1, clyde_u2)
    },
    'down': {
        'blinky': (blinky_d1, blinky_d2),
        'pinky': (pinky_d1, pinky_d2),
        'inky': (inky_d1, inky_d2),
        'clyde': (clyde_d1, clyde_d2)
    },
}


#detection collision between pacman and ghosts
def die(hero, blinky, pinky, inky, clyde):
    if hero.get_rect().colliderect(blinky.get_rect()) or\
       hero.get_rect().colliderect(pinky.get_rect()) or\
       hero.get_rect().colliderect(inky.get_rect()) or\
       hero.get_rect().colliderect(clyde.get_rect()):
        return True
    else:
        return False
#detect if we hit a powerup
def hit(pacman, pu):
  return pacman.get_rect().colliderect(pygame.Rect(pu[1], pu[2], 32, 32))