import pygame, sys, math, random
from pygame.locals import *
from resources import *
from pacman import *
from pellet import *

import time
from ghost import *



#time.sleep(100)

# (100, 186, 172, 255) COLOR OF THE WALL
pygame.init()
pygame.mixer.init()
pygame.mixer.music.load("background.mp3") 
pygame.mixer.music.play(-1,0.0)

FPS = 30
fpsClock = pygame.time.Clock()

width, height = arena.get_size()
surface = pygame.display.set_mode((width, height), 0, 32)
score = 0
pen = pygame.font.SysFont("Times New Roman", 30)
#create pacman here after completing pacman

direction = ""  #direction of the pacman
keydown = False  #only move when a key is pressed
invincible = False
player = Pacman()
pellets = pellet_init()
#Game starts below
valid_key = False
blinky = Ghost('blinky', 216, 218)
pinky = Ghost('pinky', 200, 240)
inky = Ghost('inky', 300, 300)
clyde = Ghost('clyde', 100, 218)
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
        if event.type == KEYDOWN:
            keydown = True
            if event.key == K_DOWN:
                player.direction = "down"
                valid_key = True
            if event.key == K_UP:
                player.direction = "up"
                valid_key = True
            if event.key == K_LEFT:
                player.direction = "left"
                valid_key = True
            if event.key == K_RIGHT:
                player.direction = "right"
                valid_key = True
        if event.type == KEYUP:
            keydown = False
            valid_key = False

    #show the arena
    surface.blit(arena, (0, 0))
    ############################################
    if keydown == True and valid_key == True:
        loc = player.get_pix_ahead()
        color = surface.get_at(loc)
        if dist(color, wall_color) > 5:
            player.move()

    player.chomp()
    #eat pellets
    for p in pellets:
        if player.get_rect().colliderect(p.get_rect()):
            pellets.remove(p)
            score += 1

    for p in pellets:
        surface.blit(p.image, (p.x, p.y))
    #power ups
    for p in powerups:
        surface.blit(p[0], (p[1], p[2]))
    '''add in check for loss or win here'''
    if die(player, blinky, pinky, inky, clyde) and not invincible:
      print("Sorry you have lost")

      time.sleep(3)
      pygame.quit()
      sys.exit()
    if score > 2000:
      print("You won!")
      time.sleep(3)
      pygame.quit()
      sys.exit()




    ##########################
    ## Add special power here#
    ##########################
    


      
    
      
    ''' Dont change things below'''
    blinky.chomp()
    inky.chomp()
    pinky.chomp()
    clyde.chomp()
    blinky.move(surface)
    pinky.move(surface)
    inky.move(surface)
    clyde.move(surface)
    surface.blit(player.image, (player.x, player.y))
    surface.blit(blinky.image, (blinky.x, blinky.y))
    surface.blit(inky.image, (inky.x, inky.y))
    surface.blit(pinky.image, (pinky.x, pinky.y))
    surface.blit(clyde.image, (clyde.x, clyde.y))

    #blit in the ghosts

    text = pen.render(str(score), False, (255, 0, 0))
    surface.blit(text, (275, 39))

    pygame.display.update()
    fpsClock.tick(FPS)
