import pygame, sys, math, random
from pygame.locals import *
from resources import *
from pacman import *
from pellet import *
from replit import audio
import time
from ghost import *

audio.play_file("pacman_fever.mp3")

#time.sleep(100)

# (100, 186, 172, 255) COLOR OF THE WALL
pygame.init()

FPS = 30
fpsClock = pygame.time.Clock()

width, height = arena.get_size()
surface = pygame.display.set_mode((width, height), 0, 32)
score = 0
pen = pygame.font.SysFont("Times New Roman", 30)
#create pacman here after completing pacman

direction = ""  #direction of the pacman
keydown = False  #only move when a key is pressed
invincible = False
player = Pacman()
pellets = pellet_init()
#Game starts below
valid_key = False
blinky = Ghost('blinky', 216, 218)
pinky = Ghost('pinky', 200, 240)
inky = Ghost('inky', 300, 300)
clyde = Ghost('clyde', 100, 218)
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
        if event.type == KEYDOWN:
            keydown = True
            if event.key == K_DOWN:
                player.direction = "down"
                valid_key = True
            if event.key == K_UP:
                player.direction = "up"
                valid_key = True
            if event.key == K_LEFT:
                player.direction = "left"
                valid_key = True
            if event.key == K_RIGHT:
                player.direction = "right"
                valid_key = True
        if event.type == KEYUP:
            keydown = False
            valid_key = False

    #show the arena
    surface.blit(arena, (0, 0))
    ############################################
    if keydown == True and valid_key == True:
        loc = player.get_pix_ahead()
        color = surface.get_at(loc)
        if dist(color, wall_color) > 5:
            player.move()

    player.chomp()
    #eat pellets
    for p in pellets:
        if player.get_rect().colliderect(p.get_rect()):
            pellets.remove(p)
            score += 1

    for p in pellets:
        surface.blit(p.image, (p.x, p.y))
    #power ups
    for p in powerups:
        surface.blit(p[0], (p[1], p[2]))
    '''add in check for loss or win here'''
    if die(player, blinky, pinky, inky, clyde) and not invincible:
      print("Sorry you have lost")
      audio.play_file('pacman_death.wav')
      time.sleep(3)
      pygame.quit()
      sys.exit()
    if score > 2000:
      print("You won!")
      time.sleep(3)
      pygame.quit()
      sys.exit()




    ''' add in special powers here'''
    #random.shuffle(powerups)
    magnet = powerups[0]
    if player.get_rect().colliderect(pygame.Rect(magnet[1], magnet[2], 32,
                                                 32)):
        for p in pellets:
            if p.x < player.x:
                p.x += 1
            else:
                p.x -= 1
            if p.y < player.y:
                p.y += 1
            else:
                p.y -= 1
    plant = powerups[1]
    if player.get_rect().colliderect(pygame.Rect(plant[1], plant[2], 32, 32)):
        pellets = pellet_init()

    fat = powerups[2]
    if player.get_rect().colliderect(pygame.Rect(fat[1], fat[2], 32, 32)):
        player.image = scale2x(player.image)
    
    poison = powerups[3]
    if hit(blinky, poison):
      blinky.x = SCREEN_WIDTH//2
      blinky.y = SCREEN_HEIGHT//2 - 30
    if hit(inky, poison):
      inky.x = SCREEN_WIDTH//2
      inky.y = SCREEN_HEIGHT//2 - 30
    if hit(pinky, poison):
      pinky.x = SCREEN_WIDTH//2
      pinky.y = SCREEN_HEIGHT//2 - 30
    if hit(clyde, poison):
      clyde.x = SCREEN_WIDTH//2
      clyde.y = SCREEN_HEIGHT//2 - 30

    tele = powerups[4]
    if hit(player, tele):
      player.x = clyde.x + 50
      player.y = clyde.y + 50
      player.clamp()

    nuke = powerups[5]
    if hit(player, nuke):
      pellets.clear()

    shield = powerups[6]
    if hit(player, shield):
      invincible = True
    else:
      invincible = False
    death = powerups[7]
    if hit(player, death):
      blinky.x = player.x + 50
      blinky.y = player.y + 50
      blinky.clamp()
      inky.x = player.x - 50
      inky.y = player.y - 50
      inky.clamp()
      pinky.x = player.x + 50
      pinky.y = player.y + 50
      pinky.clamp()
      
    
      
    ''' Dont change things below'''
    blinky.chomp()
    inky.chomp()
    pinky.chomp()
    clyde.chomp()
    blinky.move(surface)
    pinky.move(surface)
    inky.move(surface)
    clyde.move(surface)
    surface.blit(player.image, (player.x, player.y))
    surface.blit(blinky.image, (blinky.x, blinky.y))
    surface.blit(inky.image, (inky.x, inky.y))
    surface.blit(pinky.image, (pinky.x, pinky.y))
    surface.blit(clyde.image, (clyde.x, clyde.y))

    #blit in the ghosts

    text = pen.render(str(score), False, (255, 0, 0))
    surface.blit(text, (275, 39))

    pygame.display.update()
    fpsClock.tick(FPS)
