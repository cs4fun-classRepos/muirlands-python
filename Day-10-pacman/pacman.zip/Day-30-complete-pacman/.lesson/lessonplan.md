# Lesson plan
## main.py
```python
import pygame, sys, math, random
from pygame.locals import *
from resources import *
from pacman import *
from pellet import *
from replit import audio
import time
from ghost import *

audio.play_file("pacman_fever.mp3")

#time.sleep(100)

# (100, 186, 172, 255) COLOR OF THE WALL
pygame.init()

FPS = 30
fpsClock = pygame.time.Clock()

width, height = arena.get_size()
surface = pygame.display.set_mode((width, height), 0, 32)
score = 0
pen = pygame.font.SysFont("Times New Roman", 30)
#create pacman here after completing pacman

direction = ""  #direction of the pacman
keydown = False  #only move when a key is pressed

player = Pacman()
pellets = pellet_init()
#Game starts below
valid_key = False
blinky = Ghost('blinky', 216, 218)
pinky = Ghost('pinky', 200, 240)
inky = Ghost('inky', 300, 300)
clyde = Ghost('clyde', 100, 218)
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
        if event.type == KEYDOWN:
            keydown = True
            if event.key == K_DOWN:
                player.direction = "down"
                valid_key = True
            if event.key == K_UP:
                player.direction = "up"
                valid_key = True
            if event.key == K_LEFT:
                player.direction = "left"
                valid_key = True
            if event.key == K_RIGHT:
                player.direction = "right"
                valid_key = True
        if event.type == KEYUP:
            keydown = False
            valid_key = False

    #show the arena
    surface.blit(arena, (0, 0))
    ############################################
    if keydown == True and valid_key == True:
        loc = player.get_pix_ahead()
        color = surface.get_at(loc)
        if dist(color, wall_color) > 5:
            player.move()

    player.chomp()
    #eat pellets
    for p in pellets:
        if player.get_rect().colliderect(p.get_rect()):
            pellets.remove(p)
            score += 1

    for p in pellets:
        surface.blit(p.image, (p.x, p.y))
    #power ups
    for p in powerups:
        surface.blit(p[0], (p[1], p[2]))
    '''add in check for loss or win here'''

    if die(player, blinky, pinky, inky, clyde):
        print("YOU DIED! SCORE", score)
        audio.play_file("pacman_death.wav")
        time.sleep(4)
        pygame.quit()
        sys.exit()
    if len(pellets) == 0:
        print("YOU WON!")
        audio.play_file("pacman_beginning.mp3")
        time.sleep(30)
        pygame.quit()
        sys.exit()
    ''' add in special powers here'''
    magnet = powerups[0]
    if player.get_rect().colliderect(pygame.Rect(magnet[1], magnet[2], 32,
                                                 32)):
        for p in pellets:
            if p.x < player.x:
                p.x += 1
            else:
                p.x -= 1
            if p.y < player.y:
                p.y += 1
            else:
                p.y -= 1
    plant = powerups[1]
    if player.get_rect().colliderect(pygame.Rect(plant[1], plant[2], 32, 32)):
        pellets = pellet_init()

    fat = powerups[2]
    if player.get_rect().colliderect(pygame.Rect(fat[1], fat[2], 32, 32)):
        player.image = scale2x(player.image)
    ''' Dont change things below'''
    blinky.chomp()
    inky.chomp()
    pinky.chomp()
    clyde.chomp()
    blinky.move(surface)
    pinky.move(surface)
    inky.move(surface)
    clyde.move(surface)
    surface.blit(player.image, (player.x, player.y))
    surface.blit(blinky.image, (blinky.x, blinky.y))
    surface.blit(inky.image, (inky.x, inky.y))
    surface.blit(pinky.image, (pinky.x, pinky.y))
    surface.blit(clyde.image, (clyde.x, clyde.y))

    #blit in the ghosts

    text = pen.render(str(score), False, (255, 0, 0))
    surface.blit(text, (275, 39))

    pygame.display.update()
    fpsClock.tick(FPS)

```


## pacman.py
```python
#this is the pacman class.

#import packages
import pygame, math, random, sys
from pygame.locals import *
from resources import *

#Pacman class for our pacman game
class Pacman (pygame.sprite.Sprite):
  def __init__(self):
    super().__init__()
    self.direction = "down"
    self.image = pacman_directions[self.direction][0]
    self.x = 50
    self.y = 70
    self.speed = 5
    self.num = 0
    self.chomp_delay = 5
  def update(self):
    return
    
  def get_rect(self):
    return pygame.Rect(self.x, self.y, 32, 32)
    
  def chomp(self):
    if self.chomp_delay > 0:
      self.chomp_delay -= 1
    else:
    
      if self.num == 0:
        self.num = 1
      else:
        self.num = 0
      self.image = pacman_directions[self.direction][self.num]
      self.chomp_delay = 5

  def move(self):
    if self.direction == "down":
      self.y += self.speed
    elif self.direction == "up":
      self.y -= self.speed
    elif self.direction == "left":
      self.x -= self.speed
    elif self.direction == "right":
      self.x += self.speed
    if 200<self.y<240 and 400 < self.x < 440:
      self.x = 40
    if 200<self.y<240 and 0 < self.x < 40:
      self.x = 400 
      
  def get_pix_ahead(self):
    box = self.get_rect()
    if self.direction == "down":
      return (box.midbottom[0], box.midbottom[1] + 1)
    elif self.direction == "up":
      return (box.midtop[0], box.midtop[1] -1)
    elif self.direction == "left":
      return (box.midleft[0] - 1, box.midleft[1])
    elif self.direction == "right":
      return (box.midright[0] + 1, box.midright[1])
      
  def clamp(self):
      #bound x
      if self.x < 10:
          self.x = 10
      elif self.x > SCREEN_WIDTH - 42:
          self.x = SCREEN_WIDTH - 42
      #bound y
      if self.y < 10:
          self.y = 10
      elif self.y > SCREEN_HEIGHT - 42:
          self.y = SCREEN_HEIGHT - 42      

```

## pellet.py
```python
import pygame
from resources import *

class Pellet:
    def __init__(self, x, y, pellet_image):
        self.x = x
        self.y = y
        self.image = pellet_image
        
    def get_rect(self):
        return pygame.Rect(self.x, self.y, 4, 4)
    
def pellet_init():

    NUM_COLUMNS = 28
    NUM_ROWS = 31
    COLUMN_WIDTH = SCREEN_WIDTH / NUM_COLUMNS
    xinc = COLUMN_WIDTH
    ROW_HEIGHT = SCREEN_HEIGHT / NUM_ROWS
    yinc = ROW_HEIGHT

    linex = 0
    for i in range(NUM_COLUMNS):
        linex += COLUMN_WIDTH

    liney = 0
    for i in range(NUM_ROWS):
        liney += ROW_HEIGHT


    pellet_table = [
    [ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 ],
    [ 0,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0 ],
    [ 0,1,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0,0,0,0,1,0 ],
    [ 0,1,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0,0,0,0,1,0 ],
    [ 0,1,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0,0,0,0,1,0 ],
    [ 0,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0 ],
    [ 0,1,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,1,0 ],
    [ 0,1,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,1,0 ],
    [ 0,1,1,1,1,1,1,0,0,1,1,1,1,0,0,1,1,1,1,0,0,1,1,1,1,1,1,0 ],
    [ 0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0 ],
    [ 0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0 ],
    [ 0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0 ],
    [ 0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0 ],
    [ 0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0 ],
    [ 0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0 ],
    [ 0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0 ],
    [ 0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0 ],
    [ 0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0 ],
    [ 0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0 ],
    [ 0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0 ],
    [ 0,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0 ],
    [ 0,1,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0,0,0,0,1,0 ],
    [ 0,1,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0,0,0,0,1,0 ],
    [ 0,1,1,1,0,0,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,0,0,1,1,1,0 ],
    [ 0,0,0,1,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1,0,0,1,0,0,1,0,0,0 ],
    [ 0,0,0,1,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1,0,0,1,0,0,1,0,0,0 ],
    [ 0,1,1,1,1,1,1,0,0,1,1,1,1,0,0,1,1,1,1,0,0,1,1,1,1,1,1,0 ],
    [ 0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0 ],
    [ 0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0 ],
    [ 0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0 ],
    [ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 ],
    ]

    PELLET_PAD = ((16 - 4) / 2 ) - 1
    pellets =[]
    px, py = 0,0
    for row in pellet_table:
        px = 0
        for value in row:
            if value == 1:
                xadjusted = px + PELLET_PAD
                yadjusted = py + PELLET_PAD
                pellets.append(Pellet(xadjusted, yadjusted, pellet_image))
            px += xinc
        py += yinc
    return pellets


```


## ghost.py
```python
#This is our ghost class

#import modules
import pygame, math, random, sys
from pygame.locals import *
from resources import *

#make ghost behave similar to pacman
from pacman import *
class Ghost (Pacman):
  def __init__(self, name, x, y):
    super().__init__()
    self.name = name
    self.direction = random.choice(['left', 'right', 'up', 'down'])
    self.image = ghost_pics[self.direction][self.name][0]
    self.rect = self.image.get_rect()
    self.x = x
    self.y = y
    self.timer = 20
    
  def chomp(self):
    if self.num == 0:
      self.num = 1
    else:
      self.num = 0
    self.image = ghost_pics[self.direction][self.name][self.num]

  def move(self, surface):
    self.timer -= 1
    loc = self.get_pix_ahead()
    color = surface.get_at(loc)
    if dist(color, wall_color) > 5 and self.timer > 0:
      if self.direction == 'left':
        self.x -= self.speed
      elif self.direction == 'right':
        self.x += self.speed
      elif self.direction == 'up':
        self.y -= self.speed
      elif self.direction == 'down':
        self.y += self.speed
      self.clamp()
    else:
      self.direction = random.choice(['left', 'right', 'up', 'down'])
      self.timer = 20
    
```


## resources.py
```python
import pygame, sys, random, math
from pygame.locals import *
from pygame.transform import *

#screen dimensions
SCREEN_WIDTH = 228 * 2
SCREEN_HEIGHT = 247 * 2

#load up all the sprite sheet
sheet = pygame.image.load('pacSprites.png')

#load the empty arena
arena = pygame.image.load('arena.png')
arena = scale2x(arena)

#load pacman images
pacman_r1 = scale2x(sheet.subsurface(455, 0, 16, 16))
pacman_r2 = scale2x(sheet.subsurface(471, 0, 16, 16))
pacman_l1 = scale2x(sheet.subsurface(455, 16, 16, 16))
pacman_l2 = scale2x(sheet.subsurface(471, 16, 16, 16))
pacman_u1 = scale2x(sheet.subsurface(455, 32, 16, 16))
pacman_u2 = scale2x(sheet.subsurface(471, 32, 16, 16))
pacman_d1 = scale2x(sheet.subsurface(455, 48, 16, 16))
pacman_d2 = scale2x(sheet.subsurface(471, 48, 16, 16))

#add wall color
wall_color = (100, 186, 172, 255)

#this dictionary stores the two pictures used for
#animation for each direction for the pacman
pacman_directions = {
    "right": (pacman_r1, pacman_r2),
    "left": (pacman_l1, pacman_l2),
    "up": (pacman_u1, pacman_u2),
    "down": (pacman_d1, pacman_d2)
}
# power ups
coke = scale2x(sheet.subsurface(487, 48, 16, 16))
wine = scale2x(sheet.subsurface(503, 48, 16, 16))
cucumber = scale2x(sheet.subsurface(519, 48, 16, 16))
apple = scale2x(sheet.subsurface(535, 48, 16, 16))
grapes = scale2x(sheet.subsurface(551, 48, 16, 16))
torch = scale2x(sheet.subsurface(567, 48, 16, 16))
bread = scale2x(sheet.subsurface(583, 48, 16, 16))
pancake = scale2x(sheet.subsurface(599, 48, 16, 16))

powerups = [(coke, 90, 70), (wine, 355, 70), (cucumber, 335, 320),
            (apple, 90, 305), (grapes, 10, 455), (torch, 410, 455),
            (bread, 410, 5), (pancake, 10, 5)]


def dist(c1, c2):
    return abs(c1[0] - c2[0]) + abs(c1[1] - c2[1]) + abs(c1[2] - c2[2])


#pellet image
pellet_image = scale2x(sheet.subsurface(10, 10, 5, 5))

#ghost images
#cut blinky
blinky_r1 = scale2x(sheet.subsurface(457, 64, 14, 14))
blinky_r2 = scale2x(sheet.subsurface(473, 64, 14, 14))
blinky_l1 = scale2x(sheet.subsurface(489, 64, 14, 14))
blinky_l2 = scale2x(sheet.subsurface(505, 64, 14, 14))
blinky_u1 = scale2x(sheet.subsurface(521, 64, 14, 14))
blinky_u2 = scale2x(sheet.subsurface(537, 64, 14, 14))
blinky_d1 = scale2x(sheet.subsurface(553, 64, 14, 14))
blinky_d2 = scale2x(sheet.subsurface(569, 64, 14, 14))

#cut pinky
pinky_r1 = scale2x(sheet.subsurface(457, 81, 14, 14))
pinky_r2 = scale2x(sheet.subsurface(473, 81, 14, 14))
pinky_l1 = scale2x(sheet.subsurface(489, 81, 14, 14))
pinky_l2 = scale2x(sheet.subsurface(505, 81, 14, 14))
pinky_u1 = scale2x(sheet.subsurface(521, 81, 14, 14))
pinky_u2 = scale2x(sheet.subsurface(537, 81, 14, 14))
pinky_d1 = scale2x(sheet.subsurface(553, 81, 14, 14))
pinky_d2 = scale2x(sheet.subsurface(569, 81, 14, 14))

#cut inky
inky_r1 = scale2x(sheet.subsurface(457, 97, 14, 14))
inky_r2 = scale2x(sheet.subsurface(473, 97, 14, 14))
inky_l1 = scale2x(sheet.subsurface(489, 97, 14, 14))
inky_l2 = scale2x(sheet.subsurface(505, 97, 14, 14))
inky_u1 = scale2x(sheet.subsurface(521, 97, 14, 14))
inky_u2 = scale2x(sheet.subsurface(537, 97, 14, 14))
inky_d1 = scale2x(sheet.subsurface(553, 97, 14, 14))
inky_d2 = scale2x(sheet.subsurface(569, 97, 14, 14))

#cut clyde
clyde_r1 = scale2x(sheet.subsurface(457, 113, 14, 14))
clyde_r2 = scale2x(sheet.subsurface(473, 113, 14, 14))
clyde_l1 = scale2x(sheet.subsurface(489, 113, 14, 14))
clyde_l2 = scale2x(sheet.subsurface(505, 113, 14, 14))
clyde_u1 = scale2x(sheet.subsurface(521, 113, 14, 14))
clyde_u2 = scale2x(sheet.subsurface(537, 113, 14, 14))
clyde_d1 = scale2x(sheet.subsurface(553, 113, 14, 14))
clyde_d2 = scale2x(sheet.subsurface(569, 113, 14, 14))

#define the images of ghosts
ghost_pics = {
    'right': {
        'blinky': (blinky_r1, blinky_r2),
        'pinky': (pinky_r1, pinky_r2),
        'inky': (inky_r1, inky_r2),
        'clyde': (clyde_r1, clyde_r2)
    },
    'left': {
        'blinky': (blinky_l1, blinky_l2),
        'pinky': (pinky_l1, pinky_l2),
        'inky': (inky_l1, inky_l2),
        'clyde': (clyde_l1, clyde_l2)
    },
    'up': {
        'blinky': (blinky_u1, blinky_u2),
        'pinky': (pinky_u1, pinky_u2),
        'inky': (inky_u1, inky_u2),
        'clyde': (clyde_u1, clyde_u2)
    },
    'down': {
        'blinky': (blinky_d1, blinky_d2),
        'pinky': (pinky_d1, pinky_d2),
        'inky': (inky_d1, inky_d2),
        'clyde': (clyde_d1, clyde_d2)
    },
}


#detection collision between pacman and ghosts
def die(hero, blinky, pinky, inky, clyde):
    if hero.get_rect().colliderect(blinky.get_rect()) or\
       hero.get_rect().colliderect(pinky.get_rect()) or\
       hero.get_rect().colliderect(inky.get_rect()) or\
       hero.get_rect().colliderect(clyde.get_rect()):
        return True
    else:
        return False

```