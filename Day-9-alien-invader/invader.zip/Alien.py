import pygame, sys, random
from pygame.locals import *

class Alien(pygame.sprite.Sprite):
  def __init__(self):
    super().__init__()

    files = ['space_invader_blue.png',
            'space_invader_green.png',
            'space_invader_red.png', 'boss2.png']
    pic = random.choice(files)
    self.image = pygame.image.load(pic)
    self.rect = self.image.get_rect()
    self.rect.x = random.randint(20, 800)
    self.rect.y = random.randint(10, 40)
    self.xspeed = random.randint(-2, 2)
    self.yspeed = random.randint(1, 5)
    self.steps = 20
    self.dir = 'left'
  def update(self):
    self.rect.x += self.xspeed
    self.rect.y += self.yspeed
    if self.rect.x >= 800 or self.rect.x <= 0:
      self.xspeed *= -1
    if self.rect.y >= 400 or self.rect.y <= 0:
      self.yspeed *= -1
