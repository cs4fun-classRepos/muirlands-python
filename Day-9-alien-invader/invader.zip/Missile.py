import pygame, sys, random
from pygame.locals import *

class Missile (pygame.sprite.Sprite):
  def __init__(self):
    super().__init__()
    self.image = pygame.image.load('missile.png')
    self.rect = self.image.get_rect()
    self.xspeed = random.randint(-5, 5)
    self.yspeed = -5

  def update(self):
    self.rect.y += self.yspeed