import pygame, sys, random
from pygame.locals import *
from Spaceship import *
from Alien import *
from Missile import *


# Initialize Pygame
pygame.init()
pygame.mixer.init()
pygame.mixer.music.load("background.mp3") 
pygame.mixer.music.play(-1,0.0)
fire = pygame.mixer.Sound("shoot.wav")
myfont = pygame.font.SysFont("monospace", 32)

# Set the height and width of the screen
screen_width = 860
screen_height = 460
screen = pygame.display.set_mode([screen_width, screen_height])

# setup refresh rate of the game
FPS = 30
fpsClock = pygame.time.Clock()

score = 0
level = 1
background = pygame.image.load('background.jpg')
pygame.mouse.set_visible(False)

#create a Spaceship
player = Spaceship()
allSpriteList = pygame.sprite.Group()
missileList = pygame.sprite.Group()
alienList = pygame.sprite.Group()
allSpriteList.add(player)

# create our aliens
for i in range(50):
    alien = Alien()
    allSpriteList.add(alien)
    alienList.add(alien)
# -------- Main Program Loop -----------
while True:
    # --- Event Processing
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        #fire missiles
        if event.type == pygame.MOUSEBUTTONDOWN:
            for i in range(10):
                m = Missile()
                m.rect.x = player.rect.x + 20 * i - 100
                m.rect.y = player.rect.y
                allSpriteList.add(m)
                missileList.add(m)
                fire.play()


    #********************************
    #Code for the game control stay here
    allSpriteList.update()
    # make the background
    screen.blit(background, [0, 0])
    allSpriteList.draw(screen)
    #########################################
    #detecting collisions
    #########################################


    ########################################
    #reset levels for winning
    ########################################



    #######################################
    #reset levels for losing
    #######################################


    

    # Go ahead and update the screen with what we've drawn.
    pygame.display.update()

    # --- Limit to 30 frames per second
    fpsClock.tick(FPS)
