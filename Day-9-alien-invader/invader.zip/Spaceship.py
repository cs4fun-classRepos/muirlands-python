import pygame, sys, random
from pygame.locals import *

#define our spaceship class
class Spaceship (pygame.sprite.Sprite):
  #init function (initialize)
  def __init__(self):
    super().__init__()

    #create spaceship
    self.image = pygame.image.load('ship.png')
    self.rect = self.image.get_rect()
    self.rect.x = 200
    self.rect.y = 100

  #update function
  def update(self):
    self.rect.x = pygame.mouse.get_pos()[0]
    self.rect.y = pygame.mouse.get_pos()[1]
    
    
    
  
  