import pygame, sys, random
from pygame.locals import *

pygame.init()

#create variables
FPS = 30
fpsClock = pygame.time.Clock()


white = (255, 255, 255)
catImage = pygame.image.load('cat.png')
squiImage = pygame.image.load('squirrel.png')
background = pygame.image.load('background.jpg')
pygame.font.init()

catX = 10
catY = 10
squiX = 100
squiY = 100
DISPLAY = pygame.display.set_mode((800, 600), 0, 32)
pygame.display.set_caption('catch squirrel')
pygame.mixer.music.load('match0.wav')
caught = pygame.mixer.Sound('caught.wav')
pygame.mixer.music.play(-1)


numSqu = 0
#game loop
while True:
    #if quit game
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()


    ##################Fill in to complete the game!!##########



    ###################################################

    pygame.display.update()
    fpsClock.tick(FPS)
